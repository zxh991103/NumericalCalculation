# NumericalCalculation
## 山东大学数值计算课程实验
## finishd on 12/12 2019
## 目录
### 1-1 --> 1-8 第一章实验
### 2-1 --> 2-3 第六、七章实验
### 3-1 --> 3-1 2001年数学建模A题
### 4-0 --> 4-0 第三章实验
### 5-0 --> 5-0 第四章实验
### 6-0 --> 6-1 第五章实验
### 7-0 --> 7-0 第八章实验
### 8-0 --> 8-1 第九章实验

## 支持作者

![avatar](https://github.com/zxh991103/NumericalCalculation/blob/master/a.jpg?raw=true)


## 可加vx
